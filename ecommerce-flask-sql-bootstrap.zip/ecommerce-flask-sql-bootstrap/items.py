from flask import Blueprint, request, jsonify
from models import db, Item
from flask_jwt_extended import jwt_required

items_bp = Blueprint('items_bp', __name__)


@items_bp.route('/', methods=['GET'])
def list_items():
    query = Item.query
    min_price = request.args.get('minPrice', type=float)
    max_price = request.args.get('maxPrice', type=float)
    category = request.args.get('category', type=str)
    q = request.args.get('q', type=str)

    if min_price is not None:
        query = query.filter(Item.price >= min_price)
    if max_price is not None:
        query = query.filter(Item.price <= max_price)
    if category:
        query = query.filter(Item.category.ilike(f'%{category}%'))
    if q:
        query = query.filter(
            Item.title.ilike(f'%{q}%') | Item.description.ilike(f'%{q}%')
        )

    items = query.order_by(Item.id.desc()).all()
    return jsonify([
        {
            'id': i.id,
            'title': i.title,
            'description': i.description,
            'price': i.price,
            'category': i.category,
            'image': i.image
        } for i in items
    ])


@items_bp.route('/', methods=['POST'])
@jwt_required()
def create_item():
    data = request.get_json() or {}
    item = Item(
        title=data.get('title'),
        description=data.get('description'),
        price=float(data.get('price', 0)),
        category=data.get('category', 'General'),
        image=data.get('image')
    )
    db.session.add(item)
    db.session.commit()
    return jsonify({'msg': 'created', 'id': item.id}), 201


@items_bp.route('/<int:item_id>', methods=['PUT', 'PATCH'])
@jwt_required()
def update_item(item_id):
    item = Item.query.get_or_404(item_id)
    data = request.get_json() or {}
    item.title = data.get('title', item.title)
    item.description = data.get('description', item.description)
    item.price = float(data.get('price', item.price))
    item.category = data.get('category', item.category)
    item.image = data.get('image', item.image)
    db.session.commit()
    return jsonify({'msg': 'updated'})


@items_bp.route('/<int:item_id>', methods=['DELETE'])
@jwt_required()
def delete_item(item_id):
    item = Item.query.get_or_404(item_id)
    db.session.delete(item)
    db.session.commit()
    return jsonify({'msg': 'deleted'})
