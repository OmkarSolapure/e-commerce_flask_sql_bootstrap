from flask import Flask, render_template
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from models import db
from config import Config


def create_app():
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(Config)

    CORS(app)
    db.init_app(app)
    JWTManager(app)

    with app.app_context():
        import os
        os.makedirs('instance', exist_ok=True)
        db.create_all()

    from auth import auth_bp
    from items import items_bp
    from cart import cart_bp

    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(items_bp, url_prefix='/api/items')
    app.register_blueprint(cart_bp, url_prefix='/api/cart')

    @app.route('/')
    def index():
        return render_template('items.html')

    @app.route('/login')
    def login_page():
        return render_template('login.html')

    @app.route('/signup')
    def signup_page():
        return render_template('signup.html')

    @app.route('/cart')
    def cart_page():
        return render_template('cart.html')

    return app


if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)
