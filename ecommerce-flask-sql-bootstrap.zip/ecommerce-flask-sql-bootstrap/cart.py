from flask import Blueprint, jsonify, request
from models import db, Cart, Item
from flask_jwt_extended import jwt_required, get_jwt_identity

cart_bp = Blueprint('cart_bp', __name__)


@cart_bp.route('/', methods=['GET'])
@jwt_required()
def get_cart():
    user_id = get_jwt_identity()
    cart_items = Cart.query.filter_by(user_id=user_id).all()
    return jsonify([
        {
            'id': c.id,
            'item': {
                'id': c.item.id,
                'title': c.item.title,
                'price': c.item.price,
                'image': c.item.image
            },
            'quantity': c.quantity
        } for c in cart_items
    ])


@cart_bp.route('/add/<int:item_id>', methods=['POST'])
@jwt_required()
def add_to_cart(item_id):
    user_id = get_jwt_identity()
    item = Item.query.get_or_404(item_id)

    cart_item = Cart.query.filter_by(user_id=user_id, item_id=item.id).first()
    if cart_item:
        cart_item.quantity += 1
    else:
        cart_item = Cart(user_id=user_id, item_id=item.id, quantity=1)
        db.session.add(cart_item)

    db.session.commit()
    return jsonify({'msg': 'item added'})


@cart_bp.route('/remove/<int:item_id>', methods=['POST'])
@jwt_required()
def remove_from_cart(item_id):
    user_id = get_jwt_identity()
    cart_item = Cart.query.filter_by(user_id=user_id, item_id=item_id).first_or_404()

    db.session.delete(cart_item)
    db.session.commit()
    return jsonify({'msg': 'item removed'})


@cart_bp.route('/clear', methods=['POST'])
@jwt_required()
def clear_cart():
    user_id = get_jwt_identity()
    Cart.query.filter_by(user_id=user_id).delete()
    db.session.commit()
    return jsonify({'msg': 'cart cleared'})
