from app import create_app
from models import db, Item

app = create_app()

with app.app_context():
    # Clear old data
    Item.query.delete()

    # Add sample items
    items = [
        Item(
            title="Smartphone",
            description="Latest Android smartphone with great features.",
            price=599.99,
            category="Electronics",
            image="https://via.placeholder.com/150"
        ),
        Item(
            title="Laptop",
            description="High performance laptop for work and gaming.",
            price=1099.99,
            category="Electronics",
            image="https://via.placeholder.com/150"
        ),
        Item(
            title="Running Shoes",
            description="Comfortable running shoes for daily fitness.",
            price=79.99,
            category="Sports",
            image="https://via.placeholder.com/150"
        ),
        Item(
            title="Coffee Maker",
            description="Automatic coffee machine with timer.",
            price=129.99,
            category="Home Appliances",
            image="https://via.placeholder.com/150"
        )
    ]

    db.session.bulk_save_objects(items)
    db.session.commit()
    print("✅ Database seeded with sample items!")
